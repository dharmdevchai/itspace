<!-- Gallery modal -->

<div class="modal fade" id="view_image_modal">
  <div class="modal-dialog">
    <div class="modal-content">
        
          <div class="modal-body" style="overflow:scroll;" >
          <div class="modal-header" style="background:transparent;">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
     
         </div> 
          <div id="modal_image"></div>

          </div>
   
    </div>
  </div>           
</div>        
                
                

<script>

$(function(){
  $(".image_modal").click(function(){   
    var id = $(this).data('id');
    $.ajax({
        type: 'GET',
        url: 'admin/updates/fetch_gallery_data.php',
        data: {id:id},
        dataType: 'json',
        success: function(gallery){
            var img="images/gallery/"+gallery.image_name;
            $('#modal_image').html("<img style="+"overflow:hidden;height:100%;width:100%;"+" src="+img+">"+
            "<p>"+gallery.image_title+"</p>");
        }
      });
})})
</script>



           