<?php
	 include '../includes/conn.php';

	 $conn = $pdo->open();
	if(isset($_GET['id'])){
		try{
			$data = $conn->prepare("SELECT *, products.id AS id, products.name AS name ,products.details AS details, products_categories.name AS category_name FROM products LEFT JOIN products_categories ON products_categories.id=products.category_id WHERE products.id=:id");
			$data->execute(['id'=>$_GET['id']]);
			$output = $data->fetch();
			echo json_encode($output);
		}catch(PDOException $e){
			echo "There is some problem in connection: " . $e->getMessage();
		}	
	}
	$pdo->close();
?>
