<!--View_product_modal -->


<div class="modal fade" id="view_product_modal">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><b></b></h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="prodimg" style="display:flex;justify-content:center;"></div>
                <br>
                <div class="row">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-bs-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Description</a>
                        </li>
                    </ul></b>
                </div>
                <div class="row" style=" text-align: justify;">
                    <label class="desc " ></label><br>
                </div>
            </div>
            <div class="modal-footer">
              <form action="actions/add_to_cart.php" method="GET">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <!-- <input type="hidden" name="product_id" class="product_id">
              <input type="submit" name="add_to_cart"  value="Add To Cart "class="btn btn-primary"> -->
              </form>
            </div>
        </div>
    </div>
</div>  
                    
        
                    
                            
                         
                          
                   
               

      

<script>

$(function(){
  $(".view_product_modal").click(function(){   
    var id = $(this).data('id');
get_product_info(id);
})})


function get_product_info(id){
  $.ajax({
    type: 'GET',
    url: 'modals/get_product_details.php',
    data: {id:id},
    dataType: 'json',
    success: function(product){
      $('.cat').html(product.category_name);
      $('.desc').html(product.details);
      $('.modal-title').html(product.name);
if(product.photo!=""){
var img="images/products/"+product.photo;}
else{
  var img ="images/products/noimage.jpg";}
  $('.prodimg').html("<img style="+"vertical-align:middle;overflow:hidden;width:100%;border-radius:15px;"+" src="+img+">");
 }
 });
}
</script>
