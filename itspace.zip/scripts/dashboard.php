<script>
    $(".home")[0].className +=(" active");

   
    </script>