<script>
    $(".about")[0].className +=(" active");
</script>