<script>
window.onscroll = function() {scrollOPeration()};

var navbar = document.getElementById("navbar");

var sticky = 0;

function scrollOPeration() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky");
   
   
  }else{
    navbar.classList.remove("sticky");
  }
}
</script>