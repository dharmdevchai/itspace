<script>
    $(".gallery")[0].className +=(" active");    
</script>