<script>
    $(".shop")[0].className +=(" active");

        

           
</script>