<script>
    $(".services_dropdown")[0].className +=(" active");
</script>