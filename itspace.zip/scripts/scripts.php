<script src="bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>
<script src="bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js"></script>