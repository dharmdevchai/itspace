<script>
    $(".training")[0].className +=(" active");
</script>